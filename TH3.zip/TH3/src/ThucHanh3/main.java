package ThucHanh3;

public class main {

	public main(String[] args) throws Exception {
		GiaoDich acc = new GiaoDich(0, null, 0);
		acc.setAccountNumber(999999);
		acc.setName(null);
		acc.setBalance(50000);
	}

}
